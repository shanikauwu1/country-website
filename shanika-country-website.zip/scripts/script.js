document.querySelector(".burger").addEventListener("click", function () {
  document.querySelector(".navLinks").classList.toggle("active");
});
